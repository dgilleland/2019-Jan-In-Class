﻿using AdHocSchool.DataModels;
using System.Text;
using System.Threading.Tasks;

namespace AdHocSchool.BLL
{
    public class RegistrationController
    {
        public void RegisterFirstTermStudents(StudentRegistration cohort)
        {
            // Courses.Where(x => x.CourseId[4] == '1' && x.CourseId[5] < '5')
        }
    }
}
