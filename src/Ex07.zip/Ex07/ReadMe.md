# OLTP Sample

This OLTP sample is a "follow-along" sample for you to create with your instructor in-class. You will need to restore the required database from the `A01-School.zip`.
